<?php
// Cần PHP 7.4+
date_default_timezone_set('Asia/Ho_Chi_Minh');
ini_set('display_errors', '0');
ini_set('log_errors', '1');

const DB_DSN  = 'mysql:host=localhost;dbname=owzxfdum_donate;charset=utf8mb4';
const DB_USER = 'owzxfdum_donateuser';
const DB_PASS = 'Vantuanle2002@';

const BANK_ID      = 'MB';            // mã ngân hàng theo VietQR (MB, VCB, ACB, TCB...)
const ACCOUNT_NO   = '0886733714';    // số tài khoản đã liên kết Pay2S
const ACCOUNT_NAME = 'LEV VAN TUAN';

const PAY2S_SECRET = 'b683d025729aa0751ca9eede4ae7fb553521a9c1aacc47d6';   // khóa bí mật lấy ở trang webhook Pay2S
const OVERLAY_KEY  = 'Akl020402fjjzAfzk93hNMakkg'; // dùng trong link overlay: overlay.html?k=...
const PREFIX       = 'DNTVTL';        // tiền tố mã tham chiếu (tối đa 6 ký tự)
const MIN_AMOUNT   = 10000;           // số tiền tối thiểu
const OVERLAY_LEASE_SECONDS = 60;     // Claim lifetime in seconds.
const ANON_FALLBACK = false;          // nên giữ false: giao dịch không khớp mã chờ quản trị đối soát
const REQUIRE_REVIEW = true;         // duyệt tên/lời nhắn trước khi đưa lên live
const FPT_TTS_API_KEY = '';          // tùy chọn: khóa FPT.AI; không đưa khóa vào HTML/JavaScript
const ADMIN_PASSWORD_HASH = '$2y$10$WR61Ja2cMWhLVTIIJokje.YI5.a6yRJf3UikAQjF1gdsFSuASZ0/y';      // tạo bằng công cụ tools/admin-password.php (CLI)
const BLOCKED      = [];              // từ cấm, ví dụ ['tu1','tu2']; sẽ bị thay bằng ***
const GOOGLE_CLIENT_ID = '';
const GOOGLE_CLIENT_SECRET = '';
const GOOGLE_REDIRECT_URI = 'https://your-domain.example/google-callback.php';
const DONOR_ID_HMAC_KEY = ''; // tạo chuỗi ngẫu nhiên riêng, tối thiểu 32 ký tự

function db() {
    static $p;
    return $p ??= new PDO(DB_DSN, DB_USER, DB_PASS, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
}
// 1: thắp hương (<50k), 2: hoa quả (50k-<200k), 3: gà luộc (>=200k)
function tier(int $a) { return $a >= 200000 ? 3 : ($a >= 50000 ? 2 : 1); }
function maxlen(int $a) { return tier($a) === 1 ? 100 : 225; }
function clean($s, $max) {
    $s = preg_replace('/[\x00-\x1F\x7F]/u', ' ', (string)$s);
    $s = trim(mb_substr($s, 0, $max));
    foreach (BLOCKED as $w) $s = str_ireplace($w, '***', $s);
    return $s;
}
